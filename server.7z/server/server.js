/**
 * @author Nandkumar Gangai and Harshita Shrivastava
 * @version 1.0
 * @since 26-08-2018
 * 
 * Service layer to interact with the frontend
 */

const express = require('express');
const app = express();
const cors=require('cors');

const Dao = require('./modules/data-access/data-access');
const dao = new Dao();

var parser = require("body-parser");
app.use(parser.json());
app.use(cors());


const Connection = require('./connectionMod');
const connection = new Connection();
var Company = require("./company");
const company = new Company();

const connCollection = "userCollection";
const orgCollection = "orgs";


app.post('/get-all-data', async (req, res) => {
    try {
        let result = await connection.getData(connCollection, req.body.user);
        res.end(JSON.stringify(result));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
* Getting count of connections
*/
app.post('/get-count/connections', async (req, res) => {
    try {
        let result = await connection.getConnectionCount(connCollection, req.body);
        res.end(result);
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

/*
 * Sending Connect request
 * (sender - receiver)
 */
app.post('/connect', async (req, res) => {
    try {
        let result = await connection.connect(connCollection, req.body);
        // res.end("Request Sent");
        res.end(JSON.stringify(result.result)); /*Modified above line*/
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * Accepting follow request
 * (user - requester)
 */
app.post('/accept-invitation', async (req, res) => {
    try {
        let result = await connection.acceptInvitation(connCollection, req.body);
        //console.log(result.result);
        // res.end("Request Accepted");
        res.end(JSON.stringify(result.result)); /*Modified above 2 lines*/
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * removing connection
 * (user - connection)
 */
app.post('/remove-connection', async (req, res) => {
    try {
        let result = await connection.removeConnection(connCollection, req.body);
        // res.end("Removed");
        res.end(JSON.stringify(result.result)); /*Modified above line*/
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * Blocking connection
 * (user - blockee)
 */
app.post('/block', async (req, res) => {
    try {
        let result = await connection.blockConnection(connCollection, req.body);
        // res.end("Blocked");
        res.end(JSON.stringify(result.result)); /*Modified above line*/
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
* Unblocking connection
*(user-blockee)
*/
app.post('/unblock', async (req, res) => {
    try {
        let result = await connection.unblock(connCollection, req.body);
        // res.end("Unblocked");
        res.end(JSON.stringify(result.result)); /*Modified above line*/
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * Ignoring Invitation Received
 * (user-sender)
 */
app.post('/ignore-invitation', async (req, res) => {
    try {
        let result = await connection.ignoreRequest(connCollection, req.body);
        // res.end("Request Ignored");
        res.end(JSON.stringify(result.result)); /*Modified above line*/
    }
    catch (err) {
        res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * View Invitations Sent Count
 * (user)
 */
app.post('/get-invitation-count/sent', async (req, res) => {
    try {
        let result = await connection.invitationsSentCount(connCollection, req.body);
        res.end(JSON.stringify(result));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * View Invitations Received Count
 */
app.post('/get-invitation-count/received', async (req, res) => {
    try {
        let result = await connection.invitationsReceivedCount(connCollection, req.body);
        res.end(JSON.stringify(result));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
* View Invitations Sent
*/
app.post('/get-invitations/sent', async (req, res) => {
    try {
        let result = await connection.invitationsSent(connCollection, req.body);
        var sentData = [];
        for (let s of result[0].sent) {

            sentData.push(await connection.getNameAndImage(connCollection, s))
        }
        res.end(JSON.stringify(sentData));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

/**
* View Invitations Received
*/
app.post('/get-invitations/received', async (req, res) => {
    try {
        let result = await connection.invitationsReceived(connCollection, req.body);
        var receivedData = [];
        for (let r of result[0].receive) {

            receivedData.push(await connection.getNameAndImage(connCollection, r))
        }
        res.end(JSON.stringify(receivedData));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})


/**
 * View All Connections
 */
app.post('/get-all-connections', async (req, res) => {
    try {
        let result = await connection.getConnectionsList(connCollection, req.body);
        var receivedData = [];
        for (let c of result[0].connections) {
            receivedData.push(await connection.getNameAndImage(connCollection, c))
        }
        res.end(JSON.stringify(receivedData));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

/**
 * View list of blocked users
 */
app.post('/get-block-list', async (req, res) => {
    try {
        let result = await connection.getBlockList(connCollection, req.body);
        var blockData = [];
        for (let s of result[0].blocked) {

            blockData.push(await connection.getNameAndImage(connCollection, s))
        }
        res.end(JSON.stringify(blockData));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

/**
 * View Block-list Count
 */
app.post('/block-list-count', async (req, res) => {
    try {
        let result = await connection.blockListCount(connCollection, req.body);
        res.end(JSON.stringify(result));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

/**
 * Follow a company
 */
app.post('/follow-company', async (req, res) => {
    try {
        let result = await connection.followCompany(connCollection, orgCollection, req.body);
        res.end(JSON.stringify(result));
    }
    catch (err) {
                res.end(JSON.stringify({"error":err}));/*Modified*/
    }
})

//--------------------------

/**
 * Getting data of a company based on ID
 * (companyId)
 * CO
 */
app.post('/orgs/get/', async (req, res) => {
    let result = await company.getData(orgCollection, req.body);
    res.send(result);
})
/**
 * List of Jobs
 * (companyId)
 * CO
 */
app.post('/orgs/getJobList/', async (req, res) => {
    
    let result = await company.jobList(orgCollection, req.body);
    res.send(result);
});

/**
 * Getting specific job post
 * (companyId,jobId)
 * CO
 */

app.post('/orgs/getJob/', async (req, res) => {
    
    let result = await company.getJobDetails(orgCollection, req.body);
    res.send(result);
});

/**
 * Adding job post details
 * (companyId, jobId, jobPosition, postDate, lastDate, applicants*)
 * CO
 */
app.post('/orgs/postJob/', async (req, res) => {
    let result;
    try {
        result = await company.addJobPost(orgCollection, req.body);
    } 
    catch (err) {
        result = {"err":err};
    }
    res.send(result);
})
/**
 * Removing job post details
 * (companyId, jobId)
 * CO
 */
app.post('/orgs/removeJob/', async (req, res) => {
    let result;
    try {
        result = await company.removeJobPost(orgCollection, req.body);
    } 
    catch (err) {
        result = {"err":err};
    }
    res.send(result);
})

/**
 * Adding new post
 * (companyId, postId, content)
 * CO
 */
app.post('/orgs/add-post/', async (req, res) => {
    let result;
    try {
        result = await company.addPost(orgCollection, req.body);
    } 
    catch (err) {
        result = {"err":err};
    }
    res.send(result);
})

/**
 * Add like to post
 * (companyId, postId, user)
 * CO
 */
app.post('/orgs/like-post/', async (req, res) => {
    let result;
    try {
        result = await company.likePost(orgCollection, req.body);
    } 
    catch (err) {
        result = {"err":err};
    }
    res.send(result);
})

/**
 * List of applicants
 *  (companyId, jobId)
 */
app.post('/orgs/applicant-list/', async (req, res) => {
    let result = await company.applicantList(orgCollection, req.body);    
    res.send(result);    
})


/**
 * Getting applicant count
 *  (companyId, jobId)
 */
app.post('/orgs/applicant-count/', async (req, res) => {
    let result;
    try {
        result = await company.getApplicantCount(orgCollection, req.body)
    } 
    catch(err) {
        result = {err:err}
    }
    res.send(result);
});

/**
*@description Add follower
* (companyId, jobId, applicant) 8/31/2018
*/
app.post('/orgs/add-follower/', async (req, res) => {
    let result;
    try {
        result = await company.addFollower(orgCollection, req.body)
    } 
    catch(err) {
        result = {err:err}
    }
    res.send(result);
});


/**
*@description Remove follower
* (companyId, jobId, applicant) 8/31/2018
*/
app.post('/orgs/remove-follower/', async (req, res) => {
    let result;
    try {
        result = await company.removeFollower(orgCollection, req.body)
    } 
    catch(err) {
        result = {err:err}
    }
    res.send(result);
});
app.listen('8080', () => console.log('Listening on port 8080'));