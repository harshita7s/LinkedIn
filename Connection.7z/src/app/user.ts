export class USER {
    "_id": String;
    "userName": String;
    "name": String;
    "email": String;
    "mobile": String;
    "gender": String;
    "dateOfBirth": String;
    "isVerified": Boolean;
    "isDeleted": Boolean;
    "profile": {
        "bio": String;
        "image": String;
        "experience": [
            {
                "designation": String;
                "companyName": String;
                "timePeriod": String;
            }
        ],
        "education": [
            {
                "degreeName": String;
                "university": String;
                "percentage": String;
                "yearOfPassing": String;
            }
        ],
        "accomplishment": {
            "certifications": [
                {
                    "name": String;
                    "issuedBy": String;
                    "year": String;
                }
            ],
            "awards": [
                {
                    "name": String;
                    "awardedBy": String;
                    "year": String;
                }
            ],
            "publications": [
                {
                    "name": String;
                    "topic": String;
                    "publishedBy": String;
                    "year": String;
                }
            ]
        },
        "skills": [String],
        "endorsements": [
            {
                "endorsedBy": String;
                "comment": String;
            }
        ]
    };
    "posts": [
        {
            "postId": String;
            "content": String;
            "timestamp": String;
            "likes": [
                {
                    "likedBy": String;
                    "timestamp": String;
                }
            ],
            "comments": [
                {
                    "commentBy": String;
                    "content": String;
                    "timestamp": String;
                }
            ]
        },
        {
            "postId": String;
            "comments": [
                {
                    "commentBy": String;
                    "content": String;
                    "timestamp": String;
                }
            ]
        }
    ];
    "blocklist": {
        "blocked": [String],
        "blockedBy": [String]
    };
    "connectionRequests": {
        "sent": [String],
        "receive": [String]
    };
    "followingCompany": [String];
    "followers": [String];
    "connections": [String]
}