export class ConnectionData{
    _id:String;
    user:String;
    profile:String;
}